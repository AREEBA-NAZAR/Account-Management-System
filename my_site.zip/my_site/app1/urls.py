from django.urls import path
from . import views
urlpatterns = [
    path('add/', views.add_company, name='add_company'),
    path('all/', views.list_company, name='list_company'),
    path('companies/<int:company_id>/create-account/', views.create_account, name='create_account'),
    path('accounts/<int:account_id>/add-income/', views.add_income, name='add_income'),
    path('accounts/<int:account_id>/submit-expense/', views.submit_expense, name='submit_expense'),
    path('expenses/<int:expense_id>/approve/', views.approve_expense, name='approve_expense'),
    path('companies/<int:company_id>/reports/', views.view_reports, name='view_reports'),
    
]