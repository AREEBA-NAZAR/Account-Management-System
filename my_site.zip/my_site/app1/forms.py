from django import forms
from .models import Account, Company, Expense, Income

class IncomeForm(forms.ModelForm):
    class Meta:
        model = Income
        fields = ['amount']

class ExpenseForm(forms.ModelForm):
    class Meta:
        model = Expense
        fields = ['amount']

class CompanyForm(forms.ModelForm):
    class Meta:
        model = Company
        fields = ['name', 'owner']
class AccountForm(forms.ModelForm):
    class Meta:
        model = Account
        fields = ['company' , 'balance']

