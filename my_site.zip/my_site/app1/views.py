from datetime import timezone
from decimal import Decimal
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from .models import Company, Account, Income, Expense, Report
from django.contrib.auth.models import User
from app1.forms import CompanyForm ,AccountForm

def is_admin(user):
    return user.is_staff

@login_required
def add_company(request):
    if request.method == 'POST':
        form = CompanyForm(request.POST)
        if form.is_valid():
            Company = form.save(commit=False)
            Company.owner = request.user
            Company.save()
            return redirect(f'/app1/companies/{Company.id}/create-account/')
        else:
            return render(request, 'app1/add_Company.html', {'form': form})
    else:
        form = CompanyForm()
        return render(request, 'app1/add_Company.html', {'form': form})
    
    
def is_company_owner(user , company_id):
    return Company.objects.filter(owner=user, id=company_id).exists()

def create_account(request, company_id):
    form = AccountForm(request.POST)
    if request.method == 'POST':
        form = AccountForm(request.POST)
        if form.is_valid():
            Account = form.save(commit=False)
            Account.save()
            return redirect(f'/app1/accounts/{Account.id}/add-income/')
    return render(request, 'app1/create_account.html', {'form':form})

def list_company(request):
    company = company.objects.all()
    return render(request, 'app1/list_Company.html', {'company': company})


@user_passes_test(is_admin)
@login_required
def add_income(request, account_id):
    account = get_object_or_404(Account, id=account_id)
    if request.method == 'POST':
        amount = request.POST.get('amount')
        Income.objects.create(account=account, amount=amount, added_by=request.user)
        account.balance += Decimal(amount)
        account.save()
        return redirect('account_details', account_id=account_id)
    return render(request, 'add_income.html', {'account': account})

@login_required
def submit_expense(request, account_id):
    account = get_object_or_404(Account, id=account_id)
    if request.method == 'POST':
        amount = request.POST.get('amount')
        Expense.objects.create(account=account, amount=amount, submitted_by=request.user)
        return redirect('account_details', account_id=account_id)
    return render(request, 'submit_expense.html', {'account': account})

@user_passes_test(is_admin)
@login_required
def approve_expense(request, expense_id):
    expense = get_object_or_404(Expense, id=expense_id)
    if request.method == 'POST':
        expense.approved = True
        expense.approved_by = request.user
        expense.approved_at = timezone.now()
        expense.save()
        expense.account.balance -= expense.amount
        expense.account.save()
        return redirect('expense_list')
    return render(request, 'approve_expense.html', {'expense': expense})

@login_required
def view_reports(request, report_id):
    company = get_object_or_404(Report, id=report_id)
    if request.user == company.owner or request.user.is_staff:
        reports = company.reports.all()
        return render(request, 'view_reports.html', {'reports': reports})
    else:
        return redirect('access_denied')

