from django.shortcuts import render

# Create your views here.
from django.shortcuts import redirect,render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate , login ,logout

from .forms import SignupForm
from django.contrib import messages
def register(request):
    if request.method =="POST":
        fm = SignupForm(request.POST)
        if fm.is_valid():
            messages.success(request ,"Account created Sucessfully")
            user=fm.save()
            login(request , user)
            return redirect('home')
    else:
        fm = SignupForm()

    return render(request , 'accounts/register.html' , {'form' : fm})

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('/home')
        return render(request, 'accounts/login.html', {'error': "Username or password is invalid"})

    return render(request, 'accounts/login.html')

def home(request):
    return render(request, 'accounts/home.html')


        
def logout_view(request):
    logout(request)
    return redirect('/accounts/login/')


        
        
        
        
        
        
        
        
        
        
        